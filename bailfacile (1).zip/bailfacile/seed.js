'use strict';
// Données de démonstration : un compte propriétaire et 10 annonces dans toute la France.
// Usage : npm run seed   (compte : demo-proprio@example.com / motdepasse-demo)
const crypto = require('node:crypto');
const { one, run } = require('./db');
const email = 'demo-proprio@example.com';
let u = one('SELECT id FROM users WHERE email = ?', email);
if (!u) {
  const salt = crypto.randomBytes(16).toString('hex');
  u = run('INSERT INTO users(email,name,role,salt,hash,created) VALUES(?,?,?,?,?,?)', email, 'Propriétaire Démo', 'owner', salt,
    crypto.scryptSync('motdepasse-demo', salt, 64).toString('hex'), new Date().toISOString());
}
const L = (title, city, dept, surface, rooms, rent, charges, furn, desc) => ({ title, city, dept, surface, rooms, rent, charges, furn, desc });
const list = [
  L('Studio lumineux', 'Paris 11e', '75', 28, 1, 950, 60, true, 'Proche métro Oberkampf, cuisine équipée, fibre.'),
  L('T2 rénové', 'Lyon 3e', '69', 45, 2, 780, 70, true, 'Quartier Part-Dieu, balcon, cave.'),
  L('T3 avec terrasse', 'Marseille 8e', '13', 68, 3, 990, 110, false, 'Proche plages du Prado, parking possible.'),
  L('T2 de charme', 'Bordeaux Chartrons', '33', 42, 2, 760, 50, true, 'Pierre apparente, quartier des antiquaires.'),
  L('Studio étudiant', 'Lille Vieux-Lille', '59', 24, 1, 520, 40, true, 'À 5 min de la gare Lille-Flandres.'),
  L('T2 centre-ville', 'Toulouse Capitole', '31', 40, 2, 640, 50, true, 'Rénové, double vitrage, 3e étage.'),
  L('T3 familial', 'Nantes Île de Nantes', '44', 62, 3, 880, 90, false, 'Proche tramway, école à 200 m.'),
  L('T2 vue mer', 'Saint-Denis, La Réunion', '974', 48, 2, 620, 60, true, 'Résidence sécurisée, varangue.'),
  L('Maison T4 avec jardin', 'Ajaccio', '2A', 90, 4, 1250, 80, false, 'Jardin clos, vue sur le golfe.'),
  L('Studio moderne', 'Strasbourg Krutenau', '67', 22, 1, 480, 40, true, 'Proche campus, internet inclus.'),
];
for (const l of list) run('INSERT INTO listings(owner_id,data,created) VALUES(?,?,?)', u.id, JSON.stringify(l), new Date().toISOString());
console.log(`${list.length} annonces créées pour ${email}`);
