// Test du frontend réel contre le vrai serveur (DOM simulé)
process.env.NODE_ENV='test';process.env.DB_PATH=':memory:';
const fs=require('fs'),assert=require('assert');
const {start}=require('./server');
const PNG=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=','base64');
function makeClient(base){
 let cookie='';const els={};
 const el=id=>els[id]||(els[id]={id,innerHTML:'',style:{},value:'',textContent:''});
 const realFetch=fetch;
 const win={fetch:async(u,o={})=>{const r=await realFetch(base+u,{...o,headers:{...(o.headers||{}),...(cookie?{Cookie:cookie}:{})}});const sc=r.headers.get('set-cookie');if(sc)cookie=sc.split(';')[0];return r},scrollY:0,scrollTo(){},jspdf:undefined};
 const src=fs.readFileSync(require('path').join(__dirname,'public','index.html'),'utf8').match(/<script>([\s\S]*)<\/script>/)[1];
 const doc={getElementById:el,addEventListener(){},querySelector(){return null},createElement(){return{click(){},remove(){}}},body:{appendChild(){}}};
 const f=new Function('document','window','fetch','navigator','URL','FileReader','Blob',src+';return{S,A,api,load,render,upload,dossierOk,TODAY,tMails,docsOwner,appById};');
 const c=f(doc,win,win.fetch,{clipboard:{writeText:async()=>{}}},URL,class{},Blob);
 c.set=(id,v)=>{el(id).value=v};c.html=()=>el('app').innerHTML;
 return c;
}
(async()=>{
 const server=await start(0),base='http://localhost:'+server.address().port;
 const o=makeClient(base),t=makeClient(base);
 await new Promise(r=>setTimeout(r,200));
 assert.ok(o.html().includes('Connexion'),'écran de connexion');
 // propriétaire
 o.A.authmode();o.set('an','Paul Proprio');o.set('ar','owner');o.set('ae','proprio@ex.fr');o.set('ap','motdepasse1');await o.A.register();
 assert.equal(o.S.role,'owner');
 o.set('nt','Studio lumineux');o.set('nc','Paris 11e');o.set('nd','75');o.set('nr','950');o.set('ng','60');o.set('ns','28');o.set('nf','1');await o.A.addl();
 assert.equal(o.S.listings.length,1,'annonce créée');
 // locataire
 t.A.authmode();t.set('an','Léa Martin');t.set('ar','tenant');t.set('ae','lea@ex.fr');t.set('ap','motdepasse1');await t.A.register();
 assert.equal(t.S.tab,'dossier');
 Object.assign(t.S.profile,{nom:'Léa Martin',email:'lea@ex.fr',tel:'0600000000',revenu:'3200'});
 for(const k of ['cni','dom','paie','impots','contrat']){const r=await t.api('POST','/api/docs/'+k,{filename:k+'.png',dataBase64:PNG.toString('base64')});assert.ok(r.ok,'doc '+k)}
 await t.api('PUT','/api/profile',{...t.S.profile,guarantor:null});await t.load();
 assert.ok(t.dossierOk(),'dossier complet');
 await t.A.apply(t.S.listings[0].id);assert.equal(t.S.apps.length,1,'candidature');
 // APL + caution
 t.S.tab='dossier';t.render();assert.ok(t.html().includes('Simulation APL'),'bloc APL du dossier');
 t.set('aplm','210');t.A.aplsave();await new Promise(r=>setTimeout(r,300));await t.load();assert.equal(t.S.profile.apl.montant,210,'APL enregistrée');
 t.render();assert.ok(t.html().includes('Envoyer au propriétaire'),'bouton envoi APL');
 await t.A.sendapl(t.S.tenantApps[0].id);await t.load();assert.ok(t.S.tenantApps[0].aplSentAt,'APL envoyée');
 t.S.caution.listingId=t.S.listings[0].id;t.set('x','');Object.assign(t.S.caution,{gnom:'Paul Martin',gadr:'1 rue A',gmail:'p@x.fr',start:'2027-02-01'});t.A.cgen();
 assert.ok(t.html().includes('Télécharger l’acte')&&t.html().includes('csendform'),'boutons caution');
 t.set('csel',String(t.S.tenantApps[0].id));await t.A.csendform();await new Promise(r=>setTimeout(r,200));
 await o.load();o.S.tab='cands';o.render();assert.ok(o.html().includes('Acte de caution solidaire reçu'),'propriétaire voit l’acte');assert.ok(o.html().includes('Simulation APL du locataire'),'propriétaire voit l’APL');
 // propriétaire vérifie
 await o.load();o.S.tab='cands';o.render();
 let h=o.html();assert.ok(h.includes('Pièces du dossier')&&h.includes('/api/docs/'),'tableau des pièces avec liens');
 assert.ok(/disabled data-act="accept"/.test(h),'accept grisé');
 const id=o.S.apps[0].id;
 for(const k of ['cni','dom','paie','impots','contrat'])await o.api('POST',`/api/apps/${id}/check`,{key:k,value:'ok'});
 await o.load();o.render();assert.ok(!/disabled data-act="accept"/.test(o.html()),'accept actif');
 await o.A.accept(id);
 o.set('sd-'+id,'2027-01-10');o.set('st-'+id,'14:00');await o.A.slot(id);
 await t.load();await t.A.pick(id,0);
 o.set('bt-'+id,'meuble12');o.set('bs-'+id,'2027-02-01');await o.A.bail(id);
 await t.load();await t.A.sign(id);
 await o.load();o.S.tab='cands';o.render();h=o.html();
 assert.ok(h.includes('Télécharger le bail'),'bouton bail');assert.ok(h.includes('Paul Proprio'),'nom bailleur dans le bail');
 await o.A.pay(id,'0:late');
 o.set('rm-'+id,'Merci de régulariser');await o.A.relance(id);await o.A.mise(id);
 await t.load();t.S.tab='cands';t.render();assert.ok(t.html().includes('Courriers du propriétaire'),'courriers côté locataire');
 await t.A.openmail(id,1);await t.A.regul(id);
 await t.load();t.S.tab='mails';t.render();assert.ok(t.html().includes('Alertes e-mail')&&t.html().includes('Votre dossier est accepté'),'onglet mails locataire');
 await o.load();o.S.tab='mails';o.render();assert.ok(o.html().includes('Nouvelle candidature'),'onglet mails propriétaire');
 // deux espaces
 o.A.space(null,'tenant');o.S.tab='annonces';o.render();h=o.html();assert.ok(!h.includes('Studio lumineux'),'ses propres annonces absentes de la recherche');assert.ok(h.includes('Déposer une annonce'),'bouton déposer une annonce');
 t.A.space(null,'owner');t.set('nt','Chambre à sous-louer');t.set('nc','Lyon');t.set('nd','69');t.set('nr','400');t.set('ng','30');t.set('ns','12');t.set('nf','1');await t.A.addl();
 assert.ok(t.html().includes('Chambre à sous-louer'),'le locataire publie depuis son compte');
 await o.A.logout();assert.ok(o.html().includes('Connexion'),'déconnexion');
 console.log('✓ frontend + serveur : parcours complet OK');server.close();process.exit(0);
})().catch(e=>{console.error('✗',e);process.exit(1)});
