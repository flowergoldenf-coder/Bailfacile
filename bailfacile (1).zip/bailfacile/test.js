'use strict';
// Test d'intégration : lance le serveur en mémoire et déroule tout le parcours. `npm test`
process.env.NODE_ENV = 'test';
process.env.DB_PATH = ':memory:';
delete process.env.RESEND_API_KEY;
const assert = require('node:assert/strict');
const { start } = require('./server');
const { all } = require('./db');

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=', 'base64');
let base; const jars = {};
async function call(who, method, url, body, raw) {
  const r = await fetch(base + url, {
    method, headers: { 'Content-Type': 'application/json', ...(jars[who] ? { Cookie: jars[who] } : {}) },
    body: body ? JSON.stringify(body) : undefined, redirect: 'manual',
  });
  const sc = r.headers.get('set-cookie'); if (sc) jars[who] = sc.split(';')[0];
  if (raw) return r;
  return { status: r.status, ...(await r.json().catch(() => ({}))) };
}
const ok = (r, msg) => assert.ok(r.status >= 200 && r.status < 300, `${msg} -> ${r.status} ${r.error || ''}`);
const mailsOf = (who) => all('SELECT subject FROM emails WHERE user_id = (SELECT id FROM users WHERE email = ?)', who).map((m) => m.subject);

(async () => {
  const server = await start(0); base = 'http://localhost:' + server.address().port;
  global.__FAKE_TODAY = '2026-11-19';

  // --- sécurité de base
  assert.equal((await call('x', 'GET', '/api/bootstrap')).status, 401, 'bootstrap sans session');
  assert.equal((await call('x', 'POST', '/api/register', { email: 'bad', password: 'motdepasse1', name: 'A', role: 'owner' })).status, 400);
  assert.equal((await call('x', 'POST', '/api/register', { email: 'a@b.fr', password: 'court', name: 'A', role: 'owner' })).status, 400);
  const raw = await fetch(base + '/api/login', { method: 'POST', headers: { 'Content-Type': 'text/plain' }, body: '{}' });
  assert.equal(raw.status, 415, 'refuse un POST non JSON (anti-CSRF)');
  const home = await fetch(base + '/'); assert.ok((home.headers.get('content-security-policy') || '').includes("default-src 'self'"));
  assert.equal((await fetch(base + '/../server.js')).status, 404, 'pas de traversée de répertoire');

  // --- comptes
  ok(await call('o', 'POST', '/api/register', { email: 'proprio@ex.fr', password: 'motdepasse1', name: 'Paul Proprio', role: 'owner' }), 'register owner');
  ok(await call('t', 'POST', '/api/register', { email: 'lea@ex.fr', password: 'motdepasse1', name: 'Léa Martin', role: 'tenant' }), 'register tenant');
  ok(await call('t2', 'POST', '/api/register', { email: 'autre@ex.fr', password: 'motdepasse1', name: 'Autre Locataire', role: 'tenant' }), 'register tenant 2');
  assert.equal((await call('x', 'POST', '/api/login', { email: 'lea@ex.fr', password: 'mauvais-mdp' })).status, 401);

  // --- annonce
  
  const li = await call('o', 'POST', '/api/listings', { title: 'Studio lumineux', city: 'Paris 11e', dept: '75', surface: 28, rooms: 1, rent: 950, charges: 60, furn: true });
  ok(li, 'listing');

  // --- dossier + candidature
  assert.equal((await call('t', 'POST', '/api/apps', { listingId: li.id })).status, 409, 'dossier incomplet refusé');
  ok(await call('t', 'PUT', '/api/profile', { nom: 'Léa Martin', email: 'lea@ex.fr', tel: '0600000000', situation: 'CDI', revenu: 3200, guarantor: { label: 'Caution de Paul (p@x.fr)', perso: { nom: 'Paul Martin', mail: 'p@x.fr' } } }), 'profile');
  assert.equal((await call('t', 'POST', '/api/docs/cni', { filename: 'virus.exe', dataBase64: Buffer.from('MZ not an image').toString('base64') })).status, 415, 'format refusé');
  for (const k of ['cni', 'dom', 'paie', 'impots', 'contrat']) ok(await call('t', 'POST', '/api/docs/' + k, { filename: k + '.png', dataBase64: PNG.toString('base64') }), 'doc ' + k);
  const ap = await call('t', 'POST', '/api/apps', { listingId: li.id }); ok(ap, 'apply');
  assert.equal((await call('t', 'POST', '/api/apps', { listingId: li.id })).status, 409, 'double candidature refusée');
  assert.ok(mailsOf('proprio@ex.fr').some((s) => s.startsWith('Nouvelle candidature')), 'mail propriétaire');

  // --- simulation APL + envoi de la caution
  assert.equal((await call('t', 'POST', `/api/apps/${ap.id}/sendapl`, {})).status, 409, 'pas d’envoi APL sans simulation');
  ok(await call('t', 'PUT', '/api/profile', { nom: 'Léa Martin', email: 'lea@ex.fr', tel: '0600000000', situation: 'CDI', revenu: 3200, apl: { montant: 215.4 }, guarantor: { label: 'Caution de Paul (p@x.fr)', perso: { nom: 'Paul Martin', mail: 'p@x.fr' } } }), 'profil + APL');
  ok(await call('t', 'POST', '/api/docs/apl', { filename: 'simu-apl.png', dataBase64: PNG.toString('base64') }), 'capture APL');
  ok(await call('t', 'PUT', '/api/profile', { nom: 'Léa Martin', email: 'lea@ex.fr', tel: '0600000000', situation: 'CDI', revenu: 3200, guarantor: null }), 'profil sans champ apl : conservé');
  assert.equal((await call('t', 'GET', '/api/bootstrap')).profile.apl.montant, 215, 'APL conservée et arrondie');
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/sendapl`, {})).status, 403, 'le propriétaire ne peut pas envoyer l’APL');
  ok(await call('t', 'POST', `/api/apps/${ap.id}/sendapl`, {}), 'envoi APL');
  assert.ok(mailsOf('proprio@ex.fr').some((s) => s.startsWith('Simulation APL de')), 'mail propriétaire APL');
  const aplFile = await call('o', 'GET', `/api/docs/${(await call('t', 'GET', '/api/bootstrap')).user.id}/apl`, null, true);
  assert.equal(aplFile.status, 200, 'propriétaire télécharge la simulation APL');
  assert.equal((await call('t', 'POST', `/api/apps/${ap.id}/csend`, { text: 'trop court' })).status, 400, 'acte vide refusé');
  const acte = 'ACTE DE CAUTIONNEMENT SOLIDAIRE\n' + 'Le garant s’engage à payer les loyers impayés. '.repeat(10);
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/csend`, { text: acte })).status, 403, 'seul le locataire envoie l’acte');
  ok(await call('t', 'POST', `/api/apps/${ap.id}/csend`, { text: acte }), 'envoi caution');
  assert.ok(mailsOf('proprio@ex.fr').some((s) => s.startsWith('Acte de caution solidaire')), 'mail propriétaire caution');
  assert.equal((await call('o', 'GET', '/api/bootstrap')).ownerApps.find((a) => a.id === ap.id).cautionDoc.text, acte.trim(), 'le propriétaire reçoit le texte');
  assert.equal((await call('t2', 'POST', '/api/docs/apl', { filename: 'x.png', dataBase64: PNG.toString('base64') })).status, 200);

  // --- autorisations sur les pièces
  const tid = (await call('t', 'GET', '/api/bootstrap')).user.id;
  assert.equal((await call('o', 'GET', `/api/docs/${tid}/cni`, null, true)).status, 200, 'propriétaire concerné télécharge');
  assert.equal((await call('t2', 'GET', `/api/docs/${tid}/cni`, null, true)).status, 403, 'autre locataire refusé');
  assert.equal((await call('t2', 'POST', `/api/apps/${ap.id}/sign`, {})).status, 404, 'autre locataire ne voit pas la candidature');

  // --- vérification puis acceptation
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/accept`, {})).status, 409, 'accept bloqué sans vérification');
  assert.equal((await call('t', 'POST', `/api/apps/${ap.id}/accept`, {})).status, 403, 'locataire ne peut pas accepter');
  await call('o', 'POST', `/api/apps/${ap.id}/check`, { key: 'paie', value: 'ko' });
  for (const k of ['cni', 'dom', 'impots', 'contrat']) await call('o', 'POST', `/api/apps/${ap.id}/check`, { key: k, value: 'ok' });
  ok(await call('o', 'POST', `/api/apps/${ap.id}/reqdoc`, {}), 'reqdoc');
  ok(await call('t', 'POST', '/api/docs/paie', { filename: 'paie2.png', dataBase64: PNG.toString('base64') }), 'renvoi pièce');
  assert.ok(mailsOf('proprio@ex.fr').some((s) => s.startsWith('Pièce renvoyée')), 'mail pièce renvoyée');
  await call('o', 'POST', `/api/apps/${ap.id}/check`, { key: 'paie', value: 'ok' });
  ok(await call('o', 'POST', `/api/apps/${ap.id}/accept`, {}), 'accept');
  assert.ok(mailsOf('lea@ex.fr').includes('Votre dossier est accepté'));

  // --- rendez-vous, bail, signature
  ok(await call('o', 'POST', `/api/apps/${ap.id}/slot`, { d: '2026-11-25', t: '14:00' }), 'slot');
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/slot`, { d: '2020-01-01', t: '14:00' })).status, 400, 'créneau passé refusé');
  ok(await call('t', 'POST', `/api/apps/${ap.id}/pick`, { i: 0 }), 'pick');
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/bail`, { type: 'vide36', start: '2026-12-02' })).status, 400, 'bail 3 ans interdit pour un meublé');
  ok(await call('o', 'POST', `/api/apps/${ap.id}/bail`, { type: 'mobilite6', start: '2026-12-02' }), 'bail mobilité');
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/bail`, { type: 'meuble12', start: '2026-12-02' })).status, 409, 'un seul bail');
  ok(await call('t', 'POST', `/api/apps/${ap.id}/sign`, {}), 'sign');

  // --- impayés : garde-fous légaux
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/relance`, {})).status, 409, 'pas de relance sans impayé');
  await call('o', 'POST', `/api/apps/${ap.id}/pay`, { i: 0, s: 'late' });
  ok(await call('o', 'POST', `/api/apps/${ap.id}/relance`, { msg: 'Merci de régulariser.' }), 'relance');
  ok(await call('o', 'POST', `/api/apps/${ap.id}/mise`, {}), 'mise en demeure');
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/resil`, {})).status, 409, 'résiliation bloquée sans commandement');
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/cmd`, { date: '2027-01-01' })).status, 400, 'commandement daté dans le futur refusé');
  ok(await call('o', 'POST', `/api/apps/${ap.id}/cmd`, { date: '2026-11-19' }), 'commandement');
  assert.equal((await call('o', 'POST', `/api/apps/${ap.id}/resil`, {})).status, 409, 'résiliation bloquée avant 6 semaines');
  const mail = (await call('t', 'GET', '/api/bootstrap')).mails.find((m) => m.subject.startsWith('Mise en demeure'));
  assert.ok(mail && !mail.body.includes('MISE EN DEMEURE'), 'le recommandé n’est pas dévoilé par e-mail');
  global.__FAKE_TODAY = '2027-01-01'; // 6 semaines +
  ok(await call('t', 'POST', `/api/apps/${ap.id}/openmail`, { i: 1 }), 'openmail');
  ok(await call('t', 'POST', `/api/apps/${ap.id}/regul`, {}), 'regul');
  ok(await call('o', 'POST', `/api/apps/${ap.id}/resil`, {}), 'résiliation après 6 semaines');
  const fin = await call('o', 'GET', '/api/bootstrap');
  assert.ok(fin.ownerApps[0].resilie, 'bail résilié');
  assert.ok(mailsOf('lea@ex.fr').includes('Notification de résiliation du bail (courrier recommandé)'));

  // --- renouvellement (autre dossier propre)
  const t3 = await call('t3', 'POST', '/api/register', { email: 'bon@ex.fr', password: 'motdepasse1', name: 'Bon Payeur', role: 'tenant' }); ok(t3, 'register t3');
  ok(await call('t3', 'PUT', '/api/profile', { nom: 'Bon Payeur', email: 'bon@ex.fr', tel: '0611111111', situation: 'CDI', revenu: 3000 }), 'profile t3');
  for (const k of ['cni', 'dom', 'paie', 'impots', 'contrat']) ok(await call('t3', 'POST', '/api/docs/' + k, { filename: k + '.png', dataBase64: PNG.toString('base64') }), 'doc t3');
  const ap3 = await call('t3', 'POST', '/api/apps', { listingId: li.id }); ok(ap3, 'apply t3');
  for (const k of ['cni', 'dom', 'paie', 'impots', 'contrat']) await call('o', 'POST', `/api/apps/${ap3.id}/check`, { key: k, value: 'ok' });
  ok(await call('o', 'POST', `/api/apps/${ap3.id}/accept`, {}), 'accept t3');
  ok(await call('o', 'POST', `/api/apps/${ap3.id}/bail`, { type: 'mobilite6', start: '2027-02-01' }), 'bail t3');
  ok(await call('t3', 'POST', `/api/apps/${ap3.id}/sign`, {}), 'sign t3');
  assert.equal((await call('o', 'POST', `/api/apps/${ap3.id}/renew`, {})).status, 409, 'pas de prolongation avec loyers non payés');
  for (let i = 0; i < 6; i++) await call('o', 'POST', `/api/apps/${ap3.id}/pay`, { i, s: 'paid' });
  ok(await call('o', 'POST', `/api/apps/${ap3.id}/renew`, {}), 'prolongation');
  assert.equal((await call('o', 'POST', `/api/apps/${ap3.id}/renew`, {})).status, 409, 'prolongation une seule fois');
  const b3 = (await call('o', 'GET', '/api/bootstrap')).ownerApps.find((a) => a.id === ap3.id).bail;
  assert.equal(b3.months, 10); assert.equal(b3.pay.length, 10);

  // --- un compte, deux espaces : un locataire peut déposer une annonce, un propriétaire peut candidater
  const li2 = await call('t', 'POST', '/api/listings', { title: 'Chambre à sous-louer', city: 'Lyon 3e', dept: '69', surface: 12, rooms: 1, rent: 400, charges: 30, furn: true }); ok(li2, 'annonce déposée par un locataire');
  assert.equal((await call('t', 'POST', '/api/apps', { listingId: li2.id })).status, 403, 'pas de candidature à sa propre annonce');
  ok(await call('o', 'PUT', '/api/profile', { nom: 'Paul Proprio', email: 'proprio@ex.fr', tel: '0622222222', situation: 'CDI', revenu: 4000 }), 'profil du propriétaire');
  for (const k of ['cni', 'dom', 'paie', 'impots', 'contrat']) ok(await call('o', 'POST', '/api/docs/' + k, { filename: k + '.png', dataBase64: PNG.toString('base64') }), 'doc propriétaire');
  const apo = await call('o', 'POST', '/api/apps', { listingId: li2.id }); ok(apo, 'un propriétaire candidate chez un autre');
  const bt = await call('t', 'GET', '/api/bootstrap'), bo = await call('o', 'GET', '/api/bootstrap');
  assert.ok(bt.ownerApps.some((a) => a.id === apo.id), 'le locataire-propriétaire reçoit la candidature');
  assert.ok(bo.tenantApps.some((a) => a.id === apo.id), 'le candidat la voit dans son espace locataire');
  const oid = bo.user.id;
  assert.equal((await call('t', 'GET', `/api/docs/${oid}/cni`, null, true)).status, 200, 'le nouveau propriétaire télécharge les pièces du candidat');
  assert.equal((await call('t2', 'GET', `/api/docs/${oid}/cni`, null, true)).status, 403, 'un tiers ne les voit pas');
  assert.equal((await call('t', 'POST', `/api/apps/${apo.id}/sign`, {})).status, 403, 'on ne signe pas à la place du candidat');

  // --- déconnexion
  ok(await call('t', 'POST', '/api/logout', {}), 'logout');
  assert.equal((await call('t', 'GET', '/api/bootstrap')).status, 401, 'session invalidée');

  console.log('✓ tous les tests passent');
  server.close(); process.exit(0);
})().catch((e) => { console.error('✗ ÉCHEC :', e.message); process.exit(1); });
