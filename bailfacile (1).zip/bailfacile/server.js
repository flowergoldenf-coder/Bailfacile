'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { all, one, run, tx } = require('./db');
const { sendMail } = require('./mail');
const L = require('./logic');
const { HttpError, fail } = L;

const PUBLIC = path.join(__dirname, 'public');
const SESSION_DAYS = 30;
const MAX_DOC = 8 * 1024 * 1024; // 8 Mo par pièce
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.ico': 'image/x-icon' };
const CSP = "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'";

/* ---------- utilitaires ---------- */
const json = (res, status, obj, headers = {}) => {
  const body = JSON.stringify(obj);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(body);
};
const parseCookies = (h) => Object.fromEntries((h || '').split(';').map((c) => c.trim().split('=')).filter((p) => p[0]).map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new HttpError(413, 'Fichier trop volumineux.')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
const emailOk = (e) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e) && e.length <= 200;

// limitation simple des tentatives (en mémoire, par IP) pour login/inscription
const hits = new Map();
// Derrière un hébergeur (proxy), l'IP réelle est la dernière valeur ajoutée par le proxy dans X-Forwarded-For.
function clientIp(req) {
  if (process.env.TRUST_PROXY === '1') {
    const f = String(req.headers['x-forwarded-for'] || '').split(',').map((x) => x.trim()).filter(Boolean);
    if (f.length) return f[f.length - 1];
  }
  return req.socket.remoteAddress;
}
function rateLimit(ip, max = 10, windowMs = 15 * 60 * 1000) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter((t) => now - t < windowMs);
  if (arr.length >= max) fail(429, 'Trop de tentatives. Réessayez dans quelques minutes.');
  arr.push(now); hits.set(ip, arr);
}

function createSession(res, req, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  run('INSERT INTO sessions(token,user_id,expires) VALUES(?,?,?)', token, userId, Date.now() + SESSION_DAYS * 864e5);
  const secure = process.env.COOKIE_SECURE === '1' || req.headers['x-forwarded-proto'] === 'https';
  return `sid=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_DAYS * 86400}${secure ? '; Secure' : ''}`;
}
function currentUser(req) {
  const t = parseCookies(req.headers.cookie).sid;
  if (!t) return null;
  const s = one('SELECT s.expires, u.id, u.email, u.name, u.role FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token = ?', t);
  if (!s || s.expires < Date.now()) return null;
  return { id: s.id, email: s.email, name: s.name, role: s.role, token: t };
}

/* ---------- accès aux données ---------- */
const listingOut = (r) => ({ id: r.id, ownerId: r.owner_id, ownerName: r.owner_name, ...JSON.parse(r.data) });
function tenantProfile(userId) {
  const p = one('SELECT data FROM profiles WHERE user_id = ?', userId);
  const prof = p ? JSON.parse(p.data) : {};
  const docs = {}, files = {};
  for (const d of all('SELECT key, filename, mime, size FROM documents WHERE user_id = ?', userId)) { docs[d.key] = d.filename; files[d.key] = { name: d.filename, type: d.mime, size: d.size }; }
  return { nom: '', email: '', tel: '', situation: 'CDI', revenu: '', guarantor: null, ...prof, docs, files };
}
function appOut(r, withProfile = true) {
  return { id: r.id, listingId: r.listing_id, tenantId: r.tenant_id, ...JSON.parse(r.data), profile: withProfile ? tenantProfile(r.tenant_id) : undefined };
}
function ownerOwnsTenant(ownerId, tenantId) {
  return !!one('SELECT 1 AS x FROM applications a JOIN listings l ON l.id = a.listing_id WHERE a.tenant_id = ? AND l.owner_id = ? LIMIT 1', tenantId, ownerId);
}
const sniff = (b) => {
  if (b.length > 4 && b.subarray(0, 4).toString('latin1') === '%PDF') return ['application/pdf', 'pdf'];
  if (b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return ['image/png', 'png'];
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return ['image/jpeg', 'jpg'];
  if (b.length > 12 && b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP') return ['image/webp', 'webp'];
  return null;
};
const safeName = (s) => String(s || 'document').replace(/[^\w.\- àâäéèêëîïôöùûüç]/gi, '_').slice(0, 120) || 'document';

/* ---------- routes ---------- */
const routes = [];
const route = (method, pattern, handler, auth = true) =>
  routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), handler, auth });

route('POST', '/api/register', async ({ body, req, res }) => {
  rateLimit(clientIp(req));
  const email = L.str(body.email, 200).toLowerCase(), name = L.str(body.name, 80), pw = String(body.password || '');
  if (!emailOk(email)) fail(400, 'Adresse e-mail invalide.');
  if (!name) fail(400, 'Indiquez votre nom.');
  if (!['tenant', 'owner'].includes(body.role)) body.role = 'tenant'; // espace de départ : le compte donne accès aux deux espaces
  if (pw.length < 8 || pw.length > 200) fail(400, 'Mot de passe : 8 caractères minimum.');
  if (one('SELECT 1 AS x FROM users WHERE email = ?', email)) fail(409, 'Un compte existe déjà avec cet e-mail.');
  const salt = crypto.randomBytes(16).toString('hex');
  const u = run('INSERT INTO users(email,name,role,salt,hash,created) VALUES(?,?,?,?,?,?)', email, name, body.role, salt, hashPw(pw, salt), new Date().toISOString());
  run('INSERT INTO profiles(user_id,data) VALUES(?,?)', u.id, JSON.stringify({ nom: name, email, situation: 'CDI' }));
  return { status: 201, headers: { 'Set-Cookie': createSession(res, req, u.id) }, data: { ok: true } };
}, false);

route('POST', '/api/login', async ({ body, req, res }) => {
  rateLimit(clientIp(req));
  const email = L.str(body.email, 200).toLowerCase();
  const u = one('SELECT * FROM users WHERE email = ?', email);
  const ok = u && crypto.timingSafeEqual(Buffer.from(hashPw(String(body.password || ''), u.salt)), Buffer.from(u.hash));
  if (!ok) fail(401, 'E-mail ou mot de passe incorrect.');
  return { headers: { 'Set-Cookie': createSession(res, req, u.id) }, data: { ok: true } };
}, false);

route('POST', '/api/logout', async ({ user }) => {
  run('DELETE FROM sessions WHERE token = ?', user.token);
  return { headers: { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0' }, data: { ok: true } };
});

route('GET', '/api/bootstrap', async ({ user }) => {
  // Un compte = deux espaces : candidatures déposées (locataire) et candidatures reçues (propriétaire).
  const listings = all('SELECT l.*, u.name AS owner_name FROM listings l JOIN users u ON u.id = l.owner_id ORDER BY l.id DESC').map(listingOut);
  const tenantApps = all('SELECT * FROM applications WHERE tenant_id = ? ORDER BY id DESC', user.id).map((r) => appOut(r));
  const ownerApps = all('SELECT a.* FROM applications a JOIN listings l ON l.id = a.listing_id WHERE l.owner_id = ? ORDER BY a.id DESC', user.id).map((r) => appOut(r));
  const mails = all('SELECT id, to_addr, subject, body, status, created FROM emails WHERE user_id = ? ORDER BY id DESC LIMIT 100', user.id);
  return { user: { id: user.id, name: user.name, email: user.email, role: user.role }, listings, tenantApps, ownerApps, profile: tenantProfile(user.id), mails, today: L.today() };
});

route('PUT', '/api/profile', async ({ user, body }) => {
  const g = body.guarantor;
  const guarantor = g && typeof g === 'object' ? {
    label: L.str(g.label, 200),
    ...(g.perso ? { perso: { nom: L.str(g.perso.nom, 120), mail: L.str(g.perso.mail, 200) } } : {}),
  } : null;
  const prof = {
    nom: L.str(body.nom, 120), email: L.str(body.email, 200), tel: L.str(body.tel, 30),
    situation: ['CDI', 'CDD', 'Fonctionnaire', 'Indépendant', 'Étudiant', 'Retraité', 'Autre'].includes(body.situation) ? body.situation : 'Autre',
    revenu: Math.max(0, Math.min(1e7, Number(body.revenu) || 0)), guarantor,
  };
  const am = body.apl ? Number(body.apl.montant) : undefined;
  const prev = one('SELECT data FROM profiles WHERE user_id = ?', user.id);
  const old = prev ? JSON.parse(prev.data).apl : undefined;
  if (am > 0) prof.apl = { montant: Math.min(5000, Math.round(am)), date: L.today() };
  else if (am === undefined && old) prof.apl = old; // champ absent : on conserve
  run('INSERT INTO profiles(user_id,data) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET data = excluded.data', user.id, JSON.stringify(prof));
  return { ok: true };
});

route('POST', '/api/docs/:key', async ({ user, params, body }) => {
  if (!L.DOCS.includes(params.key) && !L.OPT_DOCS.includes(params.key)) fail(404, 'Pièce inconnue.');
  const buf = Buffer.from(String(body.dataBase64 || ''), 'base64');
  if (!buf.length) fail(400, 'Fichier vide.');
  if (buf.length > MAX_DOC) fail(413, 'Fichier trop volumineux (8 Mo maximum).');
  const kind = sniff(buf);
  if (!kind) fail(415, 'Format non accepté : envoyez un PDF, JPG, PNG ou WebP.');
  const base = safeName(String(body.filename || '').replace(/\.[^.]*$/, ''));
  run('INSERT INTO documents(user_id,key,filename,mime,size,content) VALUES(?,?,?,?,?,?) ON CONFLICT(user_id,key) DO UPDATE SET filename=excluded.filename, mime=excluded.mime, size=excluded.size, content=excluded.content',
    user.id, params.key, `${base}.${kind[1]}`, kind[0], buf.length, buf);
  // si le propriétaire avait redemandé cette pièce : on lève la demande et on le prévient
  const mails = [];
  for (const r of all('SELECT a.*, l.owner_id FROM applications a JOIN listings l ON l.id = a.listing_id WHERE a.tenant_id = ?', user.id)) {
    const d = JSON.parse(r.data);
    if (d.requested.includes(params.key) || d.check[params.key]) {
      d.requested = d.requested.filter((k) => k !== params.key); delete d.check[params.key];
      run('UPDATE applications SET data = ? WHERE id = ?', JSON.stringify(d), r.id);
      mails.push([r.owner_id, `Pièce renvoyée par ${user.name}`, `Nouvelle version : ${L.DOC_LABELS[params.key]}.`]);
    }
  }
  for (const m of mails) sendMail(...m);
  return { ok: true, message: 'Pièce enregistrée.' };
});

route('GET', '/api/docs/:uid/:key', async ({ user, params, query, res }) => {
  const uid = Number(params.uid);
  if (!(user.id === uid || ownerOwnsTenant(user.id, uid))) fail(403, 'Accès refusé.');
  const d = one('SELECT filename, mime, content FROM documents WHERE user_id = ? AND key = ?', uid, params.key);
  if (!d) fail(404, 'Document introuvable.');
  const inline = query.get('inline') === '1' && d.mime.startsWith('image/');
  res.writeHead(200, {
    'Content-Type': d.mime, 'Content-Length': d.content.length, 'Cache-Control': 'private, no-store',
    'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(d.filename)}`,
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(Buffer.from(d.content));
  return { raw: true };
});

route('POST', '/api/listings', async ({ user, body }) => {
  const n = (v, max) => Math.max(0, Math.min(max, Number(v) || 0));
  const data = {
    title: L.str(body.title, 100), city: L.str(body.city, 80), dept: L.str(body.dept, 4) || '—',
    surface: n(body.surface, 2000), rooms: Math.max(1, n(body.rooms, 50)), rent: n(body.rent, 100000), charges: n(body.charges, 100000),
    furn: !!body.furn, desc: L.str(body.desc, 600) || 'Annonce publiée par le propriétaire.',
  };
  if (!data.title || !data.city || !data.rent) fail(400, 'Titre, ville et loyer sont requis.');
  const r = run('INSERT INTO listings(owner_id,data,created) VALUES(?,?,?)', user.id, JSON.stringify(data), new Date().toISOString());
  return { status: 201, data: { ok: true, id: r.id, message: 'Annonce publiée.' } };
});

route('POST', '/api/apps', async ({ user, body }) => {
  const lr = one('SELECT * FROM listings WHERE id = ?', Number(body.listingId));
  if (!lr) fail(404, 'Annonce introuvable.');
  if (lr.owner_id === user.id) fail(403, 'Vous ne pouvez pas candidater à votre propre annonce.');
  const prof = tenantProfile(user.id);
  if (!L.dossierComplete(prof, Object.keys(prof.docs))) fail(409, 'Complétez votre dossier (infos et 5 pièces) avant de candidater.');
  if (one('SELECT 1 AS x FROM applications WHERE listing_id = ? AND tenant_id = ?', lr.id, user.id)) fail(409, 'Vous avez déjà candidaté à cette annonce.');
  const r = run('INSERT INTO applications(listing_id,tenant_id,data,created) VALUES(?,?,?,?)', lr.id, user.id, JSON.stringify(L.newAppData(prof)), new Date().toISOString());
  const l = JSON.parse(lr.data);
  sendMail(lr.owner_id, `Nouvelle candidature : ${l.title}`, `${user.name} a déposé un dossier complet pour « ${l.title} » (${l.city}). Téléchargez et vérifiez les pièces avant de répondre.`);
  return { status: 201, data: { ok: true, id: r.id, message: 'Dossier envoyé au propriétaire.' } };
});

route('POST', '/api/apps/:id/:action', async ({ user, params, body }) => {
  const result = tx(() => {
    const row = one('SELECT a.*, l.owner_id, l.data AS ldata FROM applications a JOIN listings l ON l.id = a.listing_id WHERE a.id = ?', Number(params.id));
    if (!row) fail(404, 'Candidature introuvable.');
    const isOwner = row.owner_id === user.id, isTenant = row.tenant_id === user.id;
    if (!isOwner && !isTenant) fail(404, 'Candidature introuvable.'); // pas de fuite d'existence
    const app = JSON.parse(row.data);
    const tenant = one('SELECT name FROM users WHERE id = ?', row.tenant_id);
    const docKeys = all('SELECT key FROM documents WHERE user_id = ?', row.tenant_id).map((d) => d.key);
    const out = L.act({ role: isOwner ? 'owner' : 'tenant', app, listing: JSON.parse(row.ldata), tenantName: tenant.name, docKeys, profile: tenantProfile(row.tenant_id) }, params.action, body || {});
    run('UPDATE applications SET data = ? WHERE id = ?', JSON.stringify(app), row.id);
    return { ...out, ownerId: row.owner_id, tenantId: row.tenant_id };
  });
  for (const m of result.mails) sendMail(m.to === 'owner' ? result.ownerId : result.tenantId, m.subject, m.body);
  return { ok: true, message: result.message };
});

/* ---------- serveur HTTP ---------- */
async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const base = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'X-Frame-Options': 'DENY' };
  try {
    if (url.pathname.startsWith('/api/')) {
      const r = routes.find((x) => x.method === req.method && x.re.test(url.pathname));
      if (!r) fail(404, 'Route inconnue.');
      const user = currentUser(req);
      if (r.auth && !user) fail(401, 'Connexion requise.');
      let body = {};
      if (req.method !== 'GET') {
        if (!(req.headers['content-type'] || '').startsWith('application/json')) fail(415, 'JSON attendu.');
        const raw = await readBody(req, url.pathname.startsWith('/api/docs/') ? 12 * 1024 * 1024 : 100 * 1024);
        try { body = raw.length ? JSON.parse(raw.toString('utf8')) : {}; } catch { fail(400, 'JSON invalide.'); }
      }
      const out = await r.handler({ req, res, user, body, params: url.pathname.match(r.re).groups || {}, query: url.searchParams });
      if (out && out.raw) return;
      if (out && out.data) return json(res, out.status || 200, out.data, { ...base, ...(out.headers || {}) });
      return json(res, 200, out, base);
    }
    // fichiers statiques
    let p = url.pathname === '/' ? '/index.html' : url.pathname;
    const file = path.normalize(path.join(PUBLIC, p));
    if (!file.startsWith(PUBLIC + path.sep) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) fail(404, 'Page introuvable.');
    res.writeHead(200, { ...base, 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', 'Content-Security-Policy': CSP, 'Cache-Control': 'no-cache' });
    fs.createReadStream(file).pipe(res);
  } catch (e) {
    if (res.headersSent) return res.end();
    if (e instanceof HttpError) return json(res, e.status, { error: e.message }, base);
    console.error(e);
    json(res, 500, { error: 'Erreur interne du serveur.' }, base);
  }
}

function start(port = process.env.PORT || 3000) {
  const server = http.createServer(handle);
  // nettoyage périodique des sessions expirées
  const t = setInterval(() => { try { run('DELETE FROM sessions WHERE expires < ?', Date.now()); } catch {} }, 6 * 3600 * 1000); t.unref();
  return new Promise((resolve) => server.listen(port, () => resolve(server)));
}

if (require.main === module) {
  start().then((s) => console.log(`BailFacile prêt sur http://localhost:${s.address().port}  (e-mails : ${process.env.RESEND_API_KEY ? 'Resend' : 'mode dev, rien n’est envoyé'})`));
}
module.exports = { start };
