'use strict';
// Règles métier de la location : candidature, bail, loyers, procédure d'impayé.
// Toutes les règles sont appliquées côté serveur (le navigateur n'est jamais cru sur parole).

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const fail = (status, msg) => { throw new HttpError(status, msg); };

const DOCS = ['cni', 'dom', 'paie', 'impots', 'contrat'];
const DOC_LABELS = {
  cni: 'Pièce d’identité', dom: 'Justificatif de domicile', paie: '3 derniers bulletins de salaire',
  impots: 'Dernier avis d’imposition', contrat: 'Contrat de travail / attestation employeur',
  apl: 'Simulation APL (CAF)',
};
const OPT_DOCS = ['apl']; // pièces facultatives, non exigées pour déposer un dossier
const TYPES = { meuble12: { months: 12, mob: false, renew: true, furn: true }, vide36: { months: 36, mob: false, renew: true, furn: false } };
for (let m = 6; m <= 10; m++) TYPES['mobilite' + m] = { months: m, mob: true, renew: false, furn: true };

const NLAB = {
  relance: 'Avertissement — loyer impayé',
  mise: 'Mise en demeure (courrier recommandé)',
  cmd: 'Commandement de payer',
  resil: 'Notification de résiliation du bail (courrier recommandé)',
};

const today = () => (process.env.NODE_ENV === 'test' && global.__FAKE_TODAY) || new Date().toISOString().slice(0, 10);
const isoOk = (s) => typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(s + 'T00:00:00Z'));
const addDays = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const addMonths = (s, n) => { const d = new Date(s + 'T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + n); return d.toISOString().slice(0, 10); };
const fmtDate = (s) => new Date(s + 'T00:00:00Z').toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
const eur = (n) => Number(n).toLocaleString('fr-FR').replace(/[  ]/g, ' ') + ' €';
const lateCount = (b) => b.pay.filter((p) => p.s === 'late').length;
const str = (v, max) => String(v ?? '').trim().slice(0, max);

function newAppData(profile) {
  return {
    status: 'envoyee', date: today(), slots: [], rdv: null, gli: false, bail: null, notices: [], imp: null,
    resilie: null, check: {}, requested: [], guarantor: profile.guarantor || null, cautionSigned: false,
  };
}

function dossierComplete(profile, docKeys) {
  return !!(profile && profile.nom && profile.email && profile.tel && Number(profile.revenu) > 0 && DOCS.every((k) => docKeys.includes(k)));
}

/**
 * Applique une action sur une candidature.
 * ctx = { role: 'owner'|'tenant', app: data JSON (muté), listing: data JSON, tenantName, docKeys }
 * Retourne { message, mails: [{ to: 'owner'|'tenant', subject, body }] }
 */
function act(ctx, name, body = {}) {
  const { role, app: a, listing: l, tenantName: tn } = ctx;
  const mails = [];
  const mailT = (subject, text) => mails.push({ to: 'tenant', subject, body: text });
  const mailO = (subject, text) => mails.push({ to: 'owner', subject, body: text });
  const need = (r) => { if (role !== r) fail(403, 'Action réservée ' + (r === 'owner' ? 'au propriétaire.' : 'au locataire.')); };
  const notify = (type, msg, reco) => {
    a.notices.push({ type, date: today(), msg, reco: !!reco, readAt: null });
    mailT(NLAB[type], reco ? 'Un courrier recommandé vous attend dans votre espace. Ouvrez-le pour en prendre connaissance.' : msg);
  };
  const b = a.bail;
  const monthly = l.rent + l.charges;

  switch (name) {
    case 'accept': {
      need('owner');
      if (a.status !== 'envoyee') fail(409, 'Ce dossier a déjà été traité.');
      if (!dossierComplete({ nom: 1, email: 1, tel: 1, revenu: 1 }, ctx.docKeys)) fail(409, 'Le dossier est incomplet.');
      if (!DOCS.every((k) => a.check[k] === 'ok')) fail(409, 'Vérifiez et validez les 5 pièces avant d’accepter.');
      a.status = 'acceptee';
      mailT('Votre dossier est accepté', 'Bonne nouvelle : le propriétaire a accepté votre dossier. Il va vous proposer un rendez-vous pour la remise des clés.');
      return { message: 'Dossier accepté.', mails };
    }
    case 'refuse': {
      need('owner');
      if (a.status !== 'envoyee') fail(409, 'Ce dossier a déjà été traité.');
      a.status = 'refusee';
      mailT('Votre dossier n’a pas été retenu', 'Le propriétaire n’a pas retenu votre dossier pour ce logement.');
      return { message: 'Dossier refusé.', mails };
    }
    case 'check': {
      need('owner');
      if (a.status !== 'envoyee') fail(409, 'Ce dossier a déjà été traité.');
      if (!DOCS.includes(body.key) && !OPT_DOCS.includes(body.key)) fail(400, 'Pièce inconnue.');
      if (body.value === 'ok' || body.value === 'ko') a.check[body.key] = body.value; else delete a.check[body.key];
      return { message: '', mails };
    }
    case 'reqdoc': {
      need('owner');
      if (a.status !== 'envoyee') fail(409, 'Ce dossier a déjà été traité.');
      a.requested = DOCS.filter((k) => a.check[k] === 'ko');
      if (!a.requested.length) fail(409, 'Aucune pièce marquée non conforme.');
      mailT('Pièces à renvoyer à votre propriétaire', 'Merci de renvoyer : ' + a.requested.map((k) => DOC_LABELS[k]).join(', ') + '.');
      return { message: 'Demande envoyée au locataire.', mails };
    }
    case 'slot': {
      need('owner');
      if (a.status !== 'acceptee') fail(409, 'Le dossier doit d’abord être accepté.');
      if (a.rdv) fail(409, 'Un rendez-vous est déjà confirmé.');
      if (!isoOk(body.d) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(body.t || '')) fail(400, 'Date ou heure invalide.');
      if (body.d < today()) fail(400, 'Le créneau est dans le passé.');
      if (a.slots.length >= 10) fail(409, 'Trop de créneaux proposés.');
      a.slots.push({ d: body.d, t: body.t });
      mailT('Créneau proposé pour la remise des clés', `Le propriétaire vous propose le ${fmtDate(body.d)} à ${body.t.replace(':', 'h')}. Connectez-vous pour choisir votre créneau.`);
      return { message: 'Créneau proposé au locataire.', mails };
    }
    case 'pick': {
      need('tenant');
      const s = a.slots[Number(body.i)];
      if (!s || a.rdv) fail(409, 'Créneau indisponible.');
      a.rdv = s;
      mailO(`Rendez-vous confirmé avec ${tn}`, `Remise des clés : ${fmtDate(s.d)} à ${s.t.replace(':', 'h')}.`);
      return { message: 'Rendez-vous confirmé.', mails };
    }
    case 'gli': {
      need('owner');
      if (a.status !== 'acceptee') fail(409, 'Le dossier doit d’abord être accepté.');
      a.gli = true;
      return { message: 'Demande d’assurance loyers impayés enregistrée.', mails };
    }
    case 'bail': {
      need('owner');
      if (a.status !== 'acceptee') fail(409, 'Le dossier doit d’abord être accepté.');
      if (b) fail(409, 'Un bail existe déjà.');
      const T = TYPES[body.type];
      if (!T || T.furn !== !!l.furn) fail(400, l.furn ? 'Logement meublé : bail d’1 an ou bail mobilité de 6 à 10 mois.' : 'Logement vide : la durée légale est de 3 ans.');
      if (!isoOk(body.start)) fail(400, 'Date d’entrée invalide.');
      a.bail = {
        type: body.type, start: body.start, months: T.months, signed: false, signedAt: null,
        end: addDays(addMonths(body.start, T.months), -1),
        pay: Array.from({ length: T.months }, (_, i) => ({ m: addMonths(body.start, i), s: 'todo' })),
      };
      mailT('Votre bail est prêt à signer', 'Le propriétaire a généré votre bail. Lisez-le et signez-le depuis votre espace.');
      return { message: 'Bail généré. Le locataire peut le signer.', mails };
    }
    case 'sign': {
      need('tenant');
      if (!b || b.signed) fail(409, 'Aucun bail à signer.');
      b.signed = true; b.signedAt = new Date().toISOString();
      mailO(`Bail signé par ${tn}`, 'Le locataire a signé le bail. Vous pouvez le télécharger depuis votre espace.');
      return { message: 'Bail signé.', mails };
    }
    case 'sendapl': {
      need('tenant');
      const ap = ctx.profile && ctx.profile.apl;
      if (!ap || !(Number(ap.montant) > 0)) fail(409, 'Enregistrez d’abord votre simulation APL dans votre dossier.');
      a.aplSentAt = new Date().toISOString();
      mailO(`Simulation APL de ${tn}`, `${tn} a joint une simulation APL à son dossier : environ ${eur(ap.montant)} par mois (estimation, non garantie). Consultez-la dans votre espace.`);
      return { message: 'Simulation APL envoyée au propriétaire.', mails };
    }
    case 'csend': {
      need('tenant');
      const t = String(body.text || '').trim();
      if (t.length < 200 || t.length > 20000) fail(400, 'Générez d’abord l’acte de caution.');
      a.cautionDoc = { text: t, sentAt: new Date().toISOString() };
      mailO(`Acte de caution solidaire de ${tn}`, `${tn} vous a transmis l’acte de caution solidaire à faire signer par son garant. Retrouvez-le et téléchargez-le dans votre espace.`);
      return { message: 'Acte de caution envoyé au propriétaire.', mails };
    }
    case 'csign': {
      need('owner');
      if (!b) fail(409, 'Aucun bail.');
      a.cautionSigned = true;
      return { message: 'Acte de caution marqué comme reçu signé.', mails };
    }
    case 'pay': {
      need('owner');
      if (!b || !b.signed) fail(409, 'Le bail doit être signé.');
      const p = b.pay[Number(body.i)];
      if (!p || !['todo', 'paid', 'late'].includes(body.s)) fail(400, 'Mois ou statut invalide.');
      p.s = body.s;
      return { message: '', mails };
    }
    case 'renew': {
      need('owner');
      if (!b || !b.signed || a.resilie) fail(409, 'Renouvellement impossible.');
      const T = TYPES[b.type];
      if (lateCount(b) || !b.pay.every((p) => p.s === 'paid')) fail(409, 'Tous les loyers doivent être payés, sans impayé.');
      if (T.mob && (b.prolonged || b.months >= 10)) fail(409, 'Le bail mobilité est déjà prolongé au maximum.');
      const ns = addDays(b.end, 1), add = T.mob ? 10 - b.months : b.months;
      b.end = addDays(addMonths(ns, add), -1);
      for (let i = 0; i < add; i++) b.pay.push({ m: addMonths(ns, i), s: 'todo' });
      if (T.mob) { b.prolonged = true; b.months = 10; }
      mailT(T.mob ? 'Votre bail est prolongé' : 'Votre bail est renouvelé',
        T.mob ? 'Votre bail mobilité est prolongé par avenant jusqu’à 10 mois.' : `Votre bail est renouvelé pour ${b.months} mois.`);
      return { message: T.mob ? 'Bail prolongé.' : 'Bail renouvelé.', mails };
    }
    case 'relance': {
      need('owner');
      if (!b || !b.signed || !lateCount(b)) fail(409, 'Aucun loyer impayé.');
      const msg = str(body.msg, 2000) || `Bonjour ${tn}, ${lateCount(b)} loyer(s) restent impayés (${eur(lateCount(b) * monthly)}). Merci de régulariser.`;
      notify('relance', msg, false);
      return { message: 'Avertissement envoyé.', mails };
    }
    case 'mise': {
      need('owner');
      if (!b || !b.signed || !lateCount(b)) fail(409, 'Aucun loyer impayé.');
      const n = lateCount(b);
      notify('mise', `MISE EN DEMEURE\n\n${tn}, vous êtes mis en demeure de payer sous 8 jours la somme de ${eur(n * monthly)} (${n} loyer(s) impayé(s)).\nÀ défaut, le bailleur pourra faire délivrer un commandement de payer visant la clause résolutoire du bail.`, true);
      return { message: 'Courrier recommandé déposé dans l’espace du locataire.', mails };
    }
    case 'cmd': {
      need('owner');
      if (!b || !b.signed || !lateCount(b)) fail(409, 'Aucun loyer impayé.');
      if (a.imp) fail(409, 'Un commandement est déjà enregistré.');
      if (!isoOk(body.date) || body.date > today()) fail(400, 'Date de délivrance invalide.');
      a.imp = { cmd: body.date };
      notify('cmd', `Un commandement de payer vous a été délivré le ${fmtDate(body.date)} pour ${eur(lateCount(b) * monthly)}.\nVous avez 6 semaines, jusqu’au ${fmtDate(addDays(body.date, 42))}, pour payer. Passé ce délai, la clause résolutoire du bail peut être acquise.\nVous pouvez demander des délais au juge et contacter l’ADIL.`, true);
      return { message: 'Commandement enregistré et notifié.', mails };
    }
    case 'resil': {
      need('owner');
      if (!b || !b.signed || a.resilie) fail(409, 'Résiliation impossible.');
      if (!lateCount(b)) fail(409, 'Aucun loyer impayé.');
      if (!a.imp || today() < addDays(a.imp.cmd, 42)) fail(409, 'La résiliation n’est possible que 6 semaines après un commandement de payer resté sans effet.');
      a.resilie = { date: today() };
      notify('resil', 'NOTIFICATION DE RÉSILIATION\n\nLe commandement de payer est resté sans effet pendant 6 semaines : la clause résolutoire est acquise et le bail est résilié.\nVous devez quitter le logement. À défaut, votre expulsion ne pourra être exécutée que sur décision de justice.\nVous pouvez saisir le juge pour demander des délais.', true);
      return { message: 'Bail résilié. Notification envoyée au locataire.', mails };
    }
    case 'openmail': {
      need('tenant');
      const n = a.notices[Number(body.i)];
      if (!n || !n.reco) fail(404, 'Courrier introuvable.');
      if (!n.readAt) { n.readAt = today(); mailO(`Courrier recommandé ouvert par ${tn}`, `Le locataire a ouvert : ${NLAB[n.type]}.`); }
      return { message: '', mails };
    }
    case 'regul': {
      need('tenant');
      if (!b || !lateCount(b)) fail(409, 'Aucun loyer impayé.');
      mailO(`Régularisation annoncée par ${tn}`, 'Le locataire indique avoir régularisé ses loyers impayés. Vérifiez votre compte, puis mettez à jour le statut des loyers.');
      return { message: 'Le propriétaire a été prévenu.', mails };
    }
    default: fail(404, 'Action inconnue.');
  }
}

module.exports = { OPT_DOCS, HttpError, fail, DOCS, DOC_LABELS, TYPES, today, isoOk, addDays, addMonths, str, newAppData, dossierComplete, act, lateCount };
