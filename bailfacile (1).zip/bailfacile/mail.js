'use strict';
// Envoi des alertes e-mail. Chaque e-mail est d'abord journalisé en base (table emails),
// puis envoyé via l'API Resend si RESEND_API_KEY est défini. Sans clé : mode "dev"
// (journalisé et affiché dans la console, rien ne part).
const { run, one } = require('./db');

const APP_URL = process.env.APP_URL || process.env.RENDER_EXTERNAL_URL || 'http://localhost:3000';
const clean = (s) => String(s).replace(/[\r\n]+/g, ' ').slice(0, 200);

async function sendMail(userId, subject, body) {
  const user = one('SELECT email FROM users WHERE id = ?', userId);
  if (!user) return;
  const text = `${body}\n\nConnectez-vous à BailFacile pour consulter le détail ou répondre : ${APP_URL}\n\n— Cet e-mail est une alerte automatique, merci de ne pas y répondre.`;
  const subj = clean(subject);
  const key = process.env.RESEND_API_KEY;
  const status = key ? 'pending' : 'dev';
  const row = run('INSERT INTO emails(user_id,to_addr,subject,body,status,created) VALUES(?,?,?,?,?,?)',
    userId, user.email, subj, text, status, new Date().toISOString());
  if (!key) {
    if (process.env.NODE_ENV !== 'test') console.log(`[mail:dev] à ${user.email} — ${subj}`);
    return;
  }
  try {
    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ from: process.env.MAIL_FROM || 'BailFacile <onboarding@resend.dev>', to: [user.email], subject: subj, text }),
    });
    run('UPDATE emails SET status = ? WHERE id = ?', r.ok ? 'sent' : `error:${r.status}`, row.id);
    if (!r.ok) console.error('[mail] échec', r.status, await r.text().catch(() => ''));
  } catch (e) {
    run('UPDATE emails SET status = ? WHERE id = ?', 'error:network', row.id);
    console.error('[mail] erreur réseau', e.message);
  }
}

module.exports = { sendMail };
