# BailFacile — plateforme de location partout en France

Dossier locataire en ligne, vérification des pièces par le propriétaire, rendez-vous de remise des clés, bail (meublé 1 an, bail mobilité 6 à 10 mois, vide 3 ans), suivi des loyers, procédure d'impayé (avertissement, recommandé, commandement, résiliation), acte de caution solidaire, **alertes e-mail à chaque message reçu**.

**Un compte, deux espaces** : chaque inscrit a un espace locataire (dossier, candidatures) et un espace propriétaire (annonces, dossiers reçus). Un locataire peut donc déposer une annonce, et un propriétaire candidater ailleurs, mais jamais à sa propre annonce.

Aucune dépendance à installer : Node.js **22.13 ou plus** suffit (SQLite et serveur HTTP sont intégrés).

## Démarrer en local
```bash
node server.js            # http://localhost:3000
npm run seed              # (facultatif) annonces de démonstration
npm test                  # tests : serveur + parcours complet du frontend
```
Sans clé d'envoi, les e-mails sont **journalisés** (onglet « Alertes e-mail » et console) mais ne partent pas.

## Mettre en ligne
**Guide pas à pas pour débutant (Render, avec `render.yaml` prêt) : voir `DEPLOY.md`.** Résumé pour autre hébergeur :
1. Hébergez le dossier sur un service Node (Render, Railway, Fly.io, un VPS…). Commande de démarrage : `node server.js`.
2. **Disque persistant** : placez la base sur un volume (`DB_PATH=/data/bailfacile.db`), sinon elle disparaît à chaque redéploiement. Faites une sauvegarde régulière de ce fichier.
3. Variables d'environnement : voir `.env.example`. Mettez `APP_URL` et `COOKIE_SECURE=1` (HTTPS obligatoire).
4. **E-mails** : créez un compte Resend, vérifiez votre domaine d'envoi (DNS : SPF et DKIM, sinon les messages finissent en spam), puis renseignez `RESEND_API_KEY` et `MAIL_FROM`. Aucune autre modification : chaque événement ci-dessous déclenche déjà un envoi.

## Alertes e-mail envoyées
- **Propriétaire** : nouvelle candidature, rendez-vous confirmé, bail signé, courrier recommandé ouvert, pièce renvoyée, régularisation annoncée.
- **Locataire** : dossier accepté ou refusé, créneau proposé, pièces à renvoyer, bail prêt à signer, bail renouvelé ou prolongé, avertissement, mise en demeure, commandement, résiliation (le contenu d'un recommandé n'est jamais envoyé par e-mail, seulement dans l'espace).

## Sécurité déjà en place
Mots de passe hachés (scrypt) · sessions par cookie HttpOnly/SameSite · limitation des tentatives de connexion · API en JSON uniquement (protection CSRF) · contrôle d'accès sur chaque donnée (un locataire ne voit que ses dossiers, un propriétaire que ceux de ses annonces, les pièces uniquement s'il y a candidature) · pièces vérifiées par leur contenu (PDF, JPG, PNG, WebP, 8 Mo max) · règles légales appliquées **côté serveur** (pas de résiliation sans commandement + 6 semaines, durées de bail selon le logement, renouvellement seulement si aucun impayé) · en-têtes CSP.

## À faire avant d'ouvrir au public
- **Juridique** : faire valider par un juriste ou l'ADIL les modèles de bail et d'acte de caution (`public/index.html`, fonctions `bailText` et `cautionText`), les CGU, mentions légales et la politique de confidentialité.
- **RGPD** : les pièces d'identité et revenus sont des données sensibles : chiffrement au repos (disque chiffré ou chiffrement applicatif), durée de conservation, suppression de compte et export des données, registre des traitements.
- **Comptes** : vérification de l'adresse e-mail à l'inscription, « mot de passe oublié ».
- **Signature** : la signature actuelle est un simple clic. Pour une valeur probante renforcée, brancher un prestataire de signature électronique et d'envoi recommandé électronique qualifié. Aujourd'hui le « recommandé » est un courrier déposé dans l'espace du locataire avec accusé de lecture.
- **Commandement de payer** : c'est un acte de commissaire de justice ; la plateforme n'en garde que la date et la notification.
- **Assurance loyers impayés** : le bouton enregistre une demande ; il faut un contrat avec un courtier ou un assureur partenaire pour souscrire réellement.
- **jsPDF** : le PDF du bail est généré dans le navigateur avec jsPDF chargé depuis cdnjs ; hébergez-le vous-même ou ajoutez une empreinte d'intégrité.
- **Montée en charge** : au-delà de quelques centaines d'utilisateurs actifs, passer sur PostgreSQL et un stockage objet pour les pièces.

## Structure
`server.js` routes et sécurité · `logic.js` règles de location · `db.js` base SQLite · `mail.js` envoi des alertes · `public/index.html` application · `seed.js` démo · `test.js`, `test-front.js` tests.
